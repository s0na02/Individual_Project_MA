# Individual Project
## Cohort analysis python package


The following python package was created in the scopes of an individual project for DS223 Maketing Analytics course. 

The python package focuses on cohort analysis.


### Installation:
---
You can install **Cohort** using 

### Usage:
---


